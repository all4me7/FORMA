# FORMA 1.9.0

Android WebView app. Build APK using GitHub Actions workflow.

System insets: native root handles bars, cutouts and keyboard on API 30+; legacy Android uses system fitting. Web content adds 0 CSS px at the top and 16 at the bottom.
